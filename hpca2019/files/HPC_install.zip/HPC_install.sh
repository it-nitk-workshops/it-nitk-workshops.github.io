#!/bin/bash
sudo killall apt apt-get
sudo rm /var/lib/apt/lists/lock
sudo rm /var/cache/apt/archives/lock
sudo rm /var/lib/dpkg/lock
sudo rm /var/lib/dpkg/lock-frontend
sudo dpkg --configure -a
sudo apt-get update
sudo apt-get -y install gcc
sudo snap install sublime-text --classic
gcc -o hello hello_openmp.c -fopenmp
./hello
sudo killall apt apt-get
sudo rm /var/lib/apt/lists/lock
sudo rm /var/cache/apt/archives/lock
sudo rm /var/lib/dpkg/lock
sudo rm /var/lib/dpkg/lock-frontend
sudo dpkg --configure -a
sudo apt-get -y install mpich
mpicc -o hello_mpi hello_mpi.c
mpirun -np 8 ./hello_mpi
